﻿using System;

namespace ASSESSMENT_6
{
    internal class PrimeNumbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of prime numbers to generate:");

            int numPrimes;
            try
            {
                numPrimes = int.Parse(Console.ReadLine());
                if (numPrimes <= 0)
                {
                    Console.WriteLine("Please enter a positive integer.");
                    return;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter a valid integer.");
                return;
            }

            int count = 0; 
            int currentNumber = 2; 

            Console.WriteLine($"The first {numPrimes} prime numbers are:");

            while (count < numPrimes)
            {
                if (IsPrime(currentNumber))
                {
                    Console.Write(currentNumber + " ");
                    count++;
                }
                currentNumber++;
            }

            Console.WriteLine();
        }

        static bool IsPrime(int num)
        {
            if (num <= 1) return false;
            if (num == 2) return true; 
            if (num % 2 == 0) return false; 

            for (int i = 3; i * i <= num; i += 2)
            {
                if (num % i == 0)
                    return false;
            }

            return true;
        }
    }
}
