﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASSESSMENT_6
{
    internal class _2_Array_Operations
    {
        static void Main(string[] args)
        {
            int[] integers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };


            // A . Find the sum of all elements. 

            int sum = 0;

            foreach (int i in integers)
            {
                sum += i;
            }

            Console.WriteLine($"the sum of all elements = {sum}");


            // B .Find the average of all elements. 

            Double avg = (double)sum / integers.Length;

            Console.WriteLine($"the average of all elements={avg}");



            //C . Find the maximum and minimum values.

            int min_value = integers.Min();
            int max_value = integers.Max();

            Console.WriteLine($"MINIMUM VALUE={min_value}\nMAXIMUM VALUE= {max_value}");


        }
    }
}
