﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASSESSMENT_6
{
    internal class _5_LinQ_Query
    {
        public class Student
        {
            public int ID { get; set; }
            public string Name { get; set; }
        }

        public class Enrollment
        {
            public int StudentID { get; set; }
            public string Course { get; set; }
        }
        static void Main()
        {

            var students = new List<Student>
        {
            new Student { ID = 1, Name = "BHAVANI" },
            new Student { ID = 2, Name = "KEERTHI" },
            new Student { ID = 3, Name = "LAKSHMI" }
        };

            var enrollments = new List<Enrollment>
        {
            new Enrollment { StudentID = 1, Course = "Math" },
            new Enrollment { StudentID = 2, Course = "History" },
            new Enrollment { StudentID = 3, Course = "Math" }
        };

            var studentCourses = from student in students
                                 join enrollment in enrollments
                                 on student.ID equals enrollment.StudentID
                                 select new
                                 {
                                     student.Name,
                                     enrollment.Course
                                 };

            foreach (var sc in studentCourses)
            {
                Console.WriteLine($"STUDENT NAME = {sc.Name} Enrolled Course = {sc.Course}");
            }
        }
    }
}
