﻿namespace ASSESSMENT_6
{
    internal class Program
    {
        static void Main(string[] args)
        {

            try
            {
                int RandomNumber = new Random().Next(100, 1000); //a random number between a specified range(100,1000)

                int Total_Attempts = 5;




                while (0 < Total_Attempts)
                {
                    Console.WriteLine("Enter the Number Between 100 and 1000");
                    int Guessed_Number = int.Parse(Console.ReadLine());

                    if (Guessed_Number > 100 && Guessed_Number < 1000)
                    {
                        if (RandomNumber == Guessed_Number)
                        {
                            Console.WriteLine("YOU GUESSED THE RIGHT NUMBER!!!");

                        }
                        else
                        {
                            Console.WriteLine($"YOU GUESSED WRONG NUMBER!!!  THE CORRECT NUMBER IS {RandomNumber}");
                        }
                    }

                    Total_Attempts--;
                    if (Total_Attempts != 0)
                        Console.WriteLine($"YOU HAVE {Total_Attempts} CHANCES LEFT");
                    else
                        Console.WriteLine("YOUR CHANCES ARE COMPLETED Better Luck Next Time");
                }

            
            
            }


            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);

            }






        }
    }
}
