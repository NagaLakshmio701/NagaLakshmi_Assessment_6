function ButtonClick() {
    const inputValue = document.getElementById('textInput').value;
    alert(`You entered: ${inputValue}`);
}
